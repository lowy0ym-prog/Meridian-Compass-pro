(function () {
  "use strict";

  var STORAGE_KEY = "canva_player_test_tap_count";
  var tapButton = document.getElementById("tapButton");
  var counterLabel = document.getElementById("counterLabel");
  var headline = document.getElementById("headline");
  var dragBox = document.getElementById("dragBox");

  var messages = [
    "This is a real, running HTML page.",
    "Buttons, taps and animation — all live.",
    "JavaScript is executing right now.",
    "Your Canvas, exactly as designed.",
    "Nice — keep going!"
  ];

  function readCount() {
    try {
      var stored = window.localStorage.getItem(STORAGE_KEY);
      return stored ? parseInt(stored, 10) : 0;
    } catch (e) {
      return 0;
    }
  }

  function writeCount(value) {
    try {
      window.localStorage.setItem(STORAGE_KEY, String(value));
    } catch (e) {
      /* localStorage unavailable — the demo still works, it just won't persist */
    }
  }

  var count = readCount();
  counterLabel.textContent = "Taps: " + count;

  tapButton.addEventListener("click", function () {
    count += 1;
    writeCount(count);
    counterLabel.textContent = "Taps: " + count;

    headline.textContent = messages[count % messages.length];
    headline.classList.remove("pop");
    // Force reflow so the animation can restart on repeated taps.
    void headline.offsetWidth;
    headline.classList.add("pop");
  });

  // Simple drag-and-drop interaction using pointer events.
  var isDragging = false;
  var offsetX = 0;
  var offsetY = 0;

  function toPageCoords(evt) {
    if (evt.touches && evt.touches.length > 0) {
      return { x: evt.touches[0].clientX, y: evt.touches[0].clientY };
    }
    return { x: evt.clientX, y: evt.clientY };
  }

  function startDrag(evt) {
    isDragging = true;
    var pos = toPageCoords(evt);
    var rect = dragBox.getBoundingClientRect();
    offsetX = pos.x - rect.left;
    offsetY = pos.y - rect.top;
    dragBox.style.position = "fixed";
    dragBox.style.left = rect.left + "px";
    dragBox.style.top = rect.top + "px";
    dragBox.style.margin = "0";
  }

  function moveDrag(evt) {
    if (!isDragging) return;
    evt.preventDefault();
    var pos = toPageCoords(evt);
    dragBox.style.left = (pos.x - offsetX) + "px";
    dragBox.style.top = (pos.y - offsetY) + "px";
  }

  function endDrag() {
    isDragging = false;
  }

  dragBox.addEventListener("mousedown", startDrag);
  window.addEventListener("mousemove", moveDrag);
  window.addEventListener("mouseup", endDrag);

  dragBox.addEventListener("touchstart", startDrag, { passive: true });
  window.addEventListener("touchmove", moveDrag, { passive: false });
  window.addEventListener("touchend", endDrag);
})();
