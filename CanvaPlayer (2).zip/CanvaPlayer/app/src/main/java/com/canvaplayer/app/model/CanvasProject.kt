package com.canvaplayer.app.model

import org.json.JSONObject
import java.util.UUID

/**
 * Represents a single imported Canvas (an HTML file or an extracted ZIP project)
 * that lives inside Canva Player's private app storage.
 *
 * [folderName] is the directory under `filesDir/canvases/` that holds this
 * project's files. [entryRelativePath] is the path, relative to that folder,
 * of the HTML file that should be loaded first (usually "index.html").
 *
 * Fully immutable by design: every field is `val`. Any "change" (renaming,
 * favoriting, updating lastOpened) must go through `.copy(...)` to produce a
 * new instance. This matters in practice, not just in principle — mutating a
 * shared instance in place breaks RecyclerView's DiffUtil, which compares an
 * "old" and "new" list to decide what to redraw: if both lists secretly point
 * at the very same mutated object, the comparison trivially says "unchanged"
 * and the UI never updates, even though the underlying data did.
 */
data class CanvasProject(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val folderName: String,
    val entryRelativePath: String,
    val dateAdded: Long = System.currentTimeMillis(),
    val lastOpened: Long = 0L,
    val favorite: Boolean = false,
    val sizeBytes: Long = 0L,
    val sourceType: SourceType = SourceType.HTML
) {
    enum class SourceType { HTML, ZIP, BUILT_IN }

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("name", name)
        put("folderName", folderName)
        put("entryRelativePath", entryRelativePath)
        put("dateAdded", dateAdded)
        put("lastOpened", lastOpened)
        put("favorite", favorite)
        put("sizeBytes", sizeBytes)
        put("sourceType", sourceType.name)
    }

    companion object {
        fun fromJson(json: JSONObject): CanvasProject = CanvasProject(
            id = json.getString("id"),
            name = json.getString("name"),
            folderName = json.getString("folderName"),
            entryRelativePath = json.getString("entryRelativePath"),
            dateAdded = json.optLong("dateAdded", System.currentTimeMillis()),
            lastOpened = json.optLong("lastOpened", 0L),
            favorite = json.optBoolean("favorite", false),
            sizeBytes = json.optLong("sizeBytes", 0L),
            sourceType = try {
                SourceType.valueOf(json.optString("sourceType", "HTML"))
            } catch (e: IllegalArgumentException) {
                SourceType.HTML
            }
        )
    }
}

enum class SortMode { NAME, DATE_ADDED, LAST_OPENED }

enum class LibraryFilter { ALL, FAVORITES, RECENT }
