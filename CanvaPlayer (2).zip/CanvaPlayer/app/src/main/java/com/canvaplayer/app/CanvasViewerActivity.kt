package com.canvaplayer.app

import android.annotation.SuppressLint
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import com.canvaplayer.app.data.CanvasRepository
import com.canvaplayer.app.databinding.ActivityCanvasViewerBinding
import com.canvaplayer.app.model.CanvasProject
import com.canvaplayer.app.util.XlsxWriter
import java.io.ByteArrayInputStream

/**
 * Runs a single imported Canvas inside a locked-down WebView.
 *
 * This is NOT a browser, and cannot be turned into one:
 * - The app requests no internet-related permission at all (see the
 *   manifest), so no network socket can be opened by anything running in
 *   this app — a Canvas's own JavaScript included — enforced by the
 *   operating system itself, not just by the code below.
 * - Top-level navigation to anywhere outside the Canvas's own local page is
 *   always blocked in shouldOverrideUrlLoading, independent of the (now
 *   nonexistent) network path.
 * - Cross-origin iframes/embeds are neutralized at the DOM level as a second,
 *   redundant layer, in case this app is ever repurposed and network access
 *   is re-added later — this guarantee should not rest on any single check.
 *
 * A Canvas's own "export/download" button (e.g. "Export for Excel") still
 * works fully offline: the bytes are pulled straight out of the page's own
 * JavaScript (a blob: or data: URL) and written to a file the user picks —
 * no network involved anywhere in that path.
 */
class CanvasViewerActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_CANVAS_ID = "extra_canvas_id"
        private const val ASSET_DOMAIN = "appassets.androidplatform.net"
        private const val ASSET_PATH_PREFIX = "/canvas/"
        private const val MIME_XLSX = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    }

    private lateinit var binding: ActivityCanvasViewerBinding
    private lateinit var repository: CanvasRepository
    private lateinit var project: CanvasProject
    private lateinit var assetLoader: WebViewAssetLoader
    private lateinit var startUrl: String

    // Holds the bytes waiting to be written once the user picks a save
    // location via the system "Save as" picker (Storage Access Framework).
    private var pendingExportBytes: ByteArray? = null

    private val saveXlsxLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument(MIME_XLSX)
    ) { uri -> writePendingExport(uri) }

    private val saveGenericLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument("*/*")
    ) { uri -> writePendingExport(uri) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCanvasViewerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        repository = CanvasRepository.getInstance(this)
        val canvasId = intent.getStringExtra(EXTRA_CANVAS_ID)
        val loaded = canvasId?.let { repository.getById(it) }

        if (loaded == null) {
            Toast.makeText(this, R.string.error_title, Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        project = loaded

        val projectDir = repository.projectDir(project)
        assetLoader = WebViewAssetLoader.Builder()
            .setDomain(ASSET_DOMAIN)
            .addPathHandler(ASSET_PATH_PREFIX, WebViewAssetLoader.InternalStoragePathHandler(this, projectDir))
            .build()
        startUrl = "https://$ASSET_DOMAIN$ASSET_PATH_PREFIX${project.entryRelativePath}"

        binding.txtCanvasName.text = project.name
        setupTopBar()
        setupBackHandling()

        try {
            setupWebView()
            loadCanvas()
        } catch (e: Exception) {
            // A WebView/device quirk should show the app's own friendly error
            // screen — never crash the app out to the home screen.
            showErrorState()
        }
    }

    // ---------------------------------------------------------------------
    // WebView setup
    // ---------------------------------------------------------------------

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        val webView = binding.webView
        val settings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.allowFileAccess = false
        settings.allowContentAccess = false
        settings.setSupportZoom(true)
        settings.builtInZoomControls = true
        settings.displayZoomControls = false
        settings.loadWithOverviewMode = true
        settings.useWideViewPort = true
        settings.mediaPlaybackRequiresUserGesture = false
        settings.cacheMode = WebSettings.LOAD_DEFAULT
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW

        // Belt-and-suspenders against any "open a new browser-like window"
        // escape hatch: a Canvas cannot pop a second window via
        // window.open()/target="_blank" — there is nowhere for it to go.
        settings.javaScriptCanOpenWindowsAutomatically = false
        settings.setSupportMultipleWindows(false)

        // Narrow, single-purpose JS bridge: it can only hand a file's bytes
        // back to Android to be saved. It exposes nothing else — no reads,
        // no device APIs, no arbitrary code execution surface.
        webView.addJavascriptInterface(ExportBridge(), "AndroidExport")

        // Two defensive, non-essential document-start scripts. Both are
        // wrapped so that if the WebView version doesn't support this API,
        // or either script throws for any reason, the Canvas still loads
        // normally — these only ever add safety, never remove functionality.
        try {
            if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
                WebViewCompat.addDocumentStartJavaScript(
                    webView,
                    """
                    (function() {
                      if (window.__cpBlobPatched) return;
                      window.__cpBlobPatched = true;
                      // Many "Export" buttons create a blob: URL, click a
                      // hidden download link, then immediately call
                      // URL.revokeObjectURL(). That revoke can race ahead of
                      // the async fetch Android does to pull the file's bytes
                      // back out of the page. Delaying the actual revoke by a
                      // few seconds (the page still thinks it happened
                      // immediately) closes that race.
                      var origRevoke = URL.revokeObjectURL.bind(URL);
                      URL.revokeObjectURL = function(url) {
                        setTimeout(function() { origRevoke(url); }, 5000);
                      };

                      // Redundant hardening: neutralize any iframe/embed/object
                      // that points at a different origin than this Canvas's
                      // own local page. This app has no internet permission at
                      // all, so such a request could never actually load
                      // anything anyway — this is a second, independent layer
                      // on top of that, not a substitute for it.
                      function isForeignOrigin(url) {
                        try {
                          var resolved = new URL(url, document.baseURI);
                          return resolved.origin !== window.location.origin;
                        } catch (e) {
                          return false;
                        }
                      }
                      function neutralizeForeignFrames(root) {
                        var els = root.querySelectorAll('iframe[src], embed[src], object[data]');
                        for (var i = 0; i < els.length; i++) {
                          var el = els[i];
                          var src = el.getAttribute('src') || el.getAttribute('data');
                          if (src && isForeignOrigin(src)) {
                            el.removeAttribute('src');
                            el.removeAttribute('data');
                          }
                        }
                      }
                      document.addEventListener('DOMContentLoaded', function() {
                        neutralizeForeignFrames(document);
                      });
                      new MutationObserver(function() {
                        neutralizeForeignFrames(document);
                      }).observe(document.documentElement || document, { childList: true, subtree: true });
                    })();
                    """.trimIndent(),
                    setOf("https://$ASSET_DOMAIN")
                )
            }
        } catch (e: Exception) {
            // Non-fatal: losing these optional hardening scripts is far
            // better than losing the app.
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                binding.progressBar.progress = newProgress
                binding.progressBar.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
            }

            // Never create a second window/tab for any reason — a Canvas has
            // exactly one page, always.
            override fun onCreateWindow(
                view: WebView?,
                isDialog: Boolean,
                isUserGesture: Boolean,
                resultMsg: android.os.Message?
            ): Boolean = false
        }

        webView.setDownloadListener { url, _, contentDisposition, mimeType, _ ->
            handleDownload(url, contentDisposition, mimeType)
        }

        webView.webViewClient = object : WebViewClient() {

            override fun shouldInterceptRequest(
                view: WebView?,
                request: WebResourceRequest?
            ): WebResourceResponse? {
                val url = request?.url ?: return super.shouldInterceptRequest(view, request)

                // Local project files always work.
                if (url.host == ASSET_DOMAIN) {
                    return assetLoader.shouldInterceptRequest(url)
                }

                // Everything else network-bound is blocked, unconditionally,
                // always — this app has no internet permission at all, so
                // this would fail regardless; this is a redundant app-level
                // block on top of that OS-level guarantee.
                val scheme = url.scheme?.lowercase()
                if (scheme == "http" || scheme == "https") {
                    return WebResourceResponse("text/plain", "UTF-8", ByteArrayInputStream(ByteArray(0)))
                }

                return super.shouldInterceptRequest(view, request)
            }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url ?: return false
                // Any top-level navigation away from this Canvas's own local
                // page — a tapped link, window.location, a form submit,
                // whatever triggers it — is always blocked. Canva Player
                // never opens an external browser and never navigates
                // anywhere but the Canvas's own local files.
                if (url.host != ASSET_DOMAIN) {
                    Toast.makeText(this@CanvasViewerActivity, R.string.external_link_blocked, Toast.LENGTH_SHORT).show()
                    return true
                }
                return false
            }

            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: android.webkit.WebResourceError?
            ) {
                super.onReceivedError(view, request, error)
                if (request?.isForMainFrame == true) {
                    showErrorState()
                }
            }
        }
    }

    private fun loadCanvas() {
        hideErrorState()
        binding.webView.loadUrl(startUrl)
    }

    // ---------------------------------------------------------------------
    // Export / download capture — entirely offline. A Canvas's "Export" or
    // "Download" button almost always works by creating a blob: (or data:)
    // URL and clicking a hidden <a download> link. Regular WebViews have no
    // UI for that, so we catch it here, pull the bytes back out of the
    // page's own JS context, and hand the user a normal Android "Save as"
    // dialog — turning a CSV export into a real .xlsx along the way. No
    // network request is ever made anywhere in this path.
    // ---------------------------------------------------------------------

    private fun handleDownload(url: String, contentDisposition: String?, mimeType: String?) {
        val suggestedName = URLUtil.guessFileName(url, contentDisposition, mimeType)
        when {
            url.startsWith("data:") -> handleDataUri(url, suggestedName)
            url.startsWith("blob:") -> fetchBlobViaJs(url, suggestedName, mimeType)
            else -> {
                // A real http(s) download would need a network request this
                // app is structurally unable to make (no internet permission
                // at all). Exports built as blob:/data: URLs — the standard,
                // common approach — are unaffected by this.
                Toast.makeText(this, R.string.import_failed, Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun handleDataUri(dataUri: String, suggestedName: String) {
        try {
            val comma = dataUri.indexOf(',')
            if (comma < 0) return
            val meta = dataUri.substring(5, comma) // strip "data:"
            val payload = dataUri.substring(comma + 1)
            val isBase64 = meta.endsWith(";base64")
            val mime = meta.removeSuffix(";base64").ifBlank { "application/octet-stream" }
            val bytes = if (isBase64) {
                Base64.decode(payload, Base64.DEFAULT)
            } else {
                java.net.URLDecoder.decode(payload, "UTF-8").toByteArray(Charsets.UTF_8)
            }
            processExportedBytes(bytes, suggestedName, mime)
        } catch (e: Exception) {
            Toast.makeText(this, R.string.import_failed, Toast.LENGTH_SHORT).show()
        }
    }

    private fun fetchBlobViaJs(blobUrl: String, suggestedName: String, mimeType: String?) {
        val escapedUrl = blobUrl.replace("\\", "\\\\").replace("\"", "\\\"")
        val escapedName = suggestedName.replace("\\", "\\\\").replace("\"", "\\\"")
        val fallbackMime = mimeType ?: "application/octet-stream"
        val js = """
            (function() {
              fetch("$escapedUrl")
                .then(function(r) { return r.blob(); })
                .then(function(blob) {
                  var reader = new FileReader();
                  reader.onloadend = function() {
                    var dataUrl = reader.result;
                    var idx = dataUrl.indexOf(',');
                    var base64 = idx >= 0 ? dataUrl.substring(idx + 1) : '';
                    AndroidExport.onBlobReady(base64, "$escapedName", blob.type || "$fallbackMime");
                  };
                  reader.readAsDataURL(blob);
                })
                .catch(function(e) { AndroidExport.onBlobError(String(e)); });
            })();
        """.trimIndent()
        binding.webView.evaluateJavascript(js, null)
    }

    /**
     * If the exported bytes look like CSV (the common case for a Canvas's
     * "Export for Excel" button), convert them into a genuine .xlsx workbook.
     * Anything else is handed to the user exactly as the Canvas produced it.
     */
    private fun processExportedBytes(bytes: ByteArray, suggestedName: String, mimeType: String) {
        val looksLikeCsv = mimeType.contains("csv", ignoreCase = true) ||
            suggestedName.endsWith(".csv", ignoreCase = true)

        if (looksLikeCsv) {
            try {
                val csvText = String(bytes, Charsets.UTF_8)
                val rows = XlsxWriter.rowsFromCsv(csvText)
                val xlsxBytes = XlsxWriter.write(rows)
                val xlsxName = suggestedName.substringBeforeLast('.', suggestedName) + ".xlsx"
                pendingExportBytes = xlsxBytes
                saveXlsxLauncher.launch(xlsxName)
                return
            } catch (e: Exception) {
                // Fall through and save the original bytes if conversion fails.
            }
        }

        pendingExportBytes = bytes
        saveGenericLauncher.launch(suggestedName)
    }

    private fun writePendingExport(uri: Uri?) {
        val bytes = pendingExportBytes
        pendingExportBytes = null
        if (uri == null || bytes == null) return
        try {
            contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
            Toast.makeText(this, R.string.export_saved, Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, R.string.import_failed, Toast.LENGTH_SHORT).show()
        }
    }

    /** Minimal, single-purpose JS bridge used only to receive exported file bytes. */
    private inner class ExportBridge {
        @JavascriptInterface
        fun onBlobReady(base64Data: String, suggestedName: String, mimeType: String) {
            runOnUiThread {
                try {
                    val bytes = Base64.decode(base64Data, Base64.DEFAULT)
                    processExportedBytes(bytes, suggestedName, mimeType)
                } catch (e: Exception) {
                    Toast.makeText(this@CanvasViewerActivity, R.string.import_failed, Toast.LENGTH_SHORT).show()
                }
            }
        }

        @JavascriptInterface
        fun onBlobError(message: String) {
            runOnUiThread {
                Toast.makeText(this@CanvasViewerActivity, R.string.import_failed, Toast.LENGTH_SHORT).show()
            }
        }
    }

    // ---------------------------------------------------------------------
    // Top bar controls
    // ---------------------------------------------------------------------

    private fun setupTopBar() {
        binding.btnBack.setOnClickListener { finish() }
        binding.btnReload.setOnClickListener { reloadWithFeedback() }

        binding.btnErrorBack.setOnClickListener { finish() }
        binding.btnErrorRetry.setOnClickListener { loadCanvas() }
    }

    /**
     * Reloading a small local file can complete in a few milliseconds, so
     * the progress bar can flash by too fast to notice — it can look like
     * nothing happened. A quick spin on the reload icon gives immediate,
     * unambiguous confirmation that the tap registered, regardless of how
     * fast the actual reload finishes.
     */
    private fun reloadWithFeedback() {
        binding.btnReload.animate()
            .rotationBy(360f)
            .setDuration(400)
            .start()
        loadCanvas()
    }

    // ---------------------------------------------------------------------
    // Error state
    // ---------------------------------------------------------------------

    private fun showErrorState() {
        binding.errorState.visibility = View.VISIBLE
        binding.webContainer.visibility = View.GONE
    }

    private fun hideErrorState() {
        binding.errorState.visibility = View.GONE
        binding.webContainer.visibility = View.VISIBLE
    }

    // ---------------------------------------------------------------------
    // Back button: internal WebView history first, then close the Canvas.
    // ---------------------------------------------------------------------

    private fun setupBackHandling() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (binding.webView.canGoBack()) {
                    binding.webView.goBack()
                } else {
                    finish()
                }
            }
        })
    }

    override fun onDestroy() {
        binding.webView.apply {
            stopLoading()
            clearHistory()
            destroy()
        }
        super.onDestroy()
    }
}
