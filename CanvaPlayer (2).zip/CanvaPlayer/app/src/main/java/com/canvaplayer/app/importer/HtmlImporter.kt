package com.canvaplayer.app.importer

import android.content.Context
import android.net.Uri
import com.canvaplayer.app.data.CanvasRepository
import com.canvaplayer.app.model.CanvasProject
import com.canvaplayer.app.util.FileUtils
import java.io.File
import java.io.FileOutputStream

/**
 * Copies a single, standalone .html/.htm file the user picked into this
 * Canvas's own private project folder as "index.html", so the original file
 * (e.g. in Downloads) never needs to be kept around.
 */
object HtmlImporter {

    fun importHtml(context: Context, uri: Uri, displayName: String): ImportResult {
        val repository = CanvasRepository.getInstance(context)
        val folderName = FileUtils.newProjectFolderName()
        val destDir = File(repository.canvasesRootDir, folderName)
        destDir.mkdirs()

        val destFile = File(destDir, "index.html")

        return try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(destFile).use { output ->
                    input.copyTo(output)
                }
            } ?: run {
                destDir.deleteRecursively()
                return ImportResult.Failure(ImportResult.FailureReason.IO_ERROR)
            }

            val project = CanvasProject(
                name = FileUtils.nameWithoutExtension(displayName).ifBlank { "Untitled Canvas" },
                folderName = folderName,
                entryRelativePath = "index.html",
                sourceType = CanvasProject.SourceType.HTML,
                sizeBytes = FileUtils.sizeOf(destDir)
            )
            repository.add(project)
            ImportResult.Success(project)
        } catch (e: Exception) {
            destDir.deleteRecursively()
            ImportResult.Failure(ImportResult.FailureReason.IO_ERROR)
        }
    }
}
