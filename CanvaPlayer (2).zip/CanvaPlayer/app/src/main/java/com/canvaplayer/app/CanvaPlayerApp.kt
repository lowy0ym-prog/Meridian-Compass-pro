package com.canvaplayer.app

import android.app.Application
import com.canvaplayer.app.data.CanvasRepository
import com.canvaplayer.app.model.CanvasProject
import com.canvaplayer.app.util.FileUtils
import com.canvaplayer.app.util.ThemeManager
import java.io.File

class CanvaPlayerApp : Application() {

    override fun onCreate() {
        super.onCreate()
        ThemeManager.applySavedMode(this)
        seedTestCanvasIfNeeded()
        seedEventCallListIfNeeded()
    }

    /**
     * Copies the bundled sample Canvas out of the APK's assets and into the
     * library on first launch only, so new users have something to tap on
     * immediately to confirm interactive HTML actually runs.
     */
    private fun seedTestCanvasIfNeeded() {
        seedBuiltInCanvas(
            prefsKey = "test_canvas_seeded",
            assetFolder = "testcanvas",
            folderName = "canvas_test_sample",
            projectId = "built_in_test_canvas",
            name = getString(R.string.test_canvas_name)
        )
    }

    /**
     * Copies the bundled "Event Call List" sample — a real, ready-to-use
     * nested family/group Canvas with inline editing and a CSV "Export for
     * Excel" button — so the export-to-.xlsx flow can be tried immediately.
     */
    private fun seedEventCallListIfNeeded() {
        seedBuiltInCanvas(
            prefsKey = "event_call_list_seeded",
            assetFolder = "eventcalllist",
            folderName = "canvas_event_call_list_sample",
            projectId = "built_in_event_call_list",
            name = getString(R.string.event_call_list_name)
        )
    }

    private fun seedBuiltInCanvas(
        prefsKey: String,
        assetFolder: String,
        folderName: String,
        projectId: String,
        name: String
    ) {
        val prefs = getSharedPreferences("canva_player_prefs", MODE_PRIVATE)
        if (prefs.getBoolean(prefsKey, false)) return

        try {
            val repository = CanvasRepository.getInstance(this)
            val destDir = File(repository.canvasesRootDir, folderName)
            if (!destDir.exists()) {
                destDir.mkdirs()
                copyAssetFolder(assetFolder, destDir)
            }

            val project = CanvasProject(
                id = projectId,
                name = name,
                folderName = folderName,
                entryRelativePath = "index.html",
                sourceType = CanvasProject.SourceType.BUILT_IN,
                sizeBytes = FileUtils.sizeOf(destDir)
            )
            if (repository.getById(project.id) == null) {
                repository.add(project)
            }
            prefs.edit().putBoolean(prefsKey, true).apply()
        } catch (e: Exception) {
            // Non-fatal: if a sample can't be copied for some reason, the
            // app continues to work normally for user-imported Canvases.
        }
    }

    private fun copyAssetFolder(assetPath: String, destDir: File) {
        val children = assets.list(assetPath) ?: return
        if (children.isEmpty()) {
            // It's a file, not a folder.
            assets.open(assetPath).use { input ->
                destDir.outputStream().use { output -> input.copyTo(output) }
            }
            return
        }
        destDir.mkdirs()
        for (child in children) {
            val childAssetPath = "$assetPath/$child"
            val childDest = File(destDir, child)
            val grandChildren = assets.list(childAssetPath)
            if (grandChildren != null && grandChildren.isNotEmpty()) {
                copyAssetFolder(childAssetPath, childDest)
            } else {
                assets.open(childAssetPath).use { input ->
                    childDest.outputStream().use { output -> input.copyTo(output) }
                }
            }
        }
    }
}
