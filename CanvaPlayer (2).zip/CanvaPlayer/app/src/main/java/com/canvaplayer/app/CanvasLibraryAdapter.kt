package com.canvaplayer.app

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.canvaplayer.app.databinding.ItemCanvasCardBinding
import com.canvaplayer.app.model.CanvasProject
import com.canvaplayer.app.util.FileUtils

class CanvasLibraryAdapter(
    private val onOpen: (CanvasProject) -> Unit,
    private val onToggleFavorite: (CanvasProject) -> Unit,
    private val onMoreOptions: (CanvasProject) -> Unit
) : RecyclerView.Adapter<CanvasLibraryAdapter.CanvasViewHolder>() {

    private val items = mutableListOf<CanvasProject>()

    fun submitList(newItems: List<CanvasProject>) {
        val diffCallback = object : DiffUtil.Callback() {
            override fun getOldListSize() = items.size
            override fun getNewListSize() = newItems.size
            override fun areItemsTheSame(oldPos: Int, newPos: Int) =
                items[oldPos].id == newItems[newPos].id
            override fun areContentsTheSame(oldPos: Int, newPos: Int) =
                items[oldPos] == newItems[newPos]
        }
        val diffResult = DiffUtil.calculateDiff(diffCallback)
        items.clear()
        items.addAll(newItems)
        diffResult.dispatchUpdatesTo(this)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CanvasViewHolder {
        val binding = ItemCanvasCardBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return CanvasViewHolder(binding)
    }

    override fun onBindViewHolder(holder: CanvasViewHolder, position: Int) {
        holder.bind(items[position])
    }

    override fun getItemCount(): Int = items.size

    inner class CanvasViewHolder(private val binding: ItemCanvasCardBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(project: CanvasProject) {
            binding.txtName.text = project.name
            binding.imgTypeIcon.setImageResource(
                if (project.sourceType == CanvasProject.SourceType.ZIP) R.drawable.ic_zip_doc
                else R.drawable.ic_html_doc
            )
            binding.txtLastOpened.text = if (project.lastOpened > 0L) {
                binding.root.context.getString(R.string.recently_opened) + " · " + FileUtils.formatDate(project.lastOpened)
            } else {
                binding.root.context.getString(R.string.never_opened)
            }
            binding.btnFavorite.setImageResource(
                if (project.favorite) R.drawable.ic_favorite_filled else R.drawable.ic_favorite_border
            )

            binding.root.setOnClickListener { onOpen(project) }
            binding.btnFavorite.setOnClickListener { onToggleFavorite(project) }
            binding.btnMore.setOnClickListener { onMoreOptions(project) }
        }
    }
}
