package com.canvaplayer.app.importer

import android.content.Context
import android.net.Uri
import com.canvaplayer.app.data.CanvasRepository
import com.canvaplayer.app.model.CanvasProject
import com.canvaplayer.app.util.FileUtils
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream

sealed class ImportResult {
    data class Success(val project: CanvasProject) : ImportResult()
    data class Failure(val reason: FailureReason) : ImportResult()

    enum class FailureReason { NO_INDEX_HTML, UNSAFE_PATH, IO_ERROR, UNSUPPORTED_FILE }
}

/**
 * Extracts a ZIP archive (typically an AI-generated HTML/CSS/JS bundle) into
 * this Canvas's own private project folder, preserving its internal directory
 * structure so that relative asset paths keep working.
 *
 * Extraction is defensively guarded against "zip-slip" path traversal:
 * every entry's resolved, canonical destination path is checked to make sure
 * it is still inside the destination project folder before anything is written.
 */
object ZipImporter {

    private const val MAX_UNCOMPRESSED_BYTES = 300L * 1024 * 1024 // 300 MB safety ceiling

    fun importZip(context: Context, uri: Uri, displayName: String): ImportResult {
        val repository = CanvasRepository.getInstance(context)
        val folderName = FileUtils.newProjectFolderName()
        val destDir = File(repository.canvasesRootDir, folderName)
        destDir.mkdirs()

        val destCanonical = destDir.canonicalFile

        var totalWritten = 0L

        try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                ZipInputStream(input).use { zip ->
                    var entry: ZipEntry? = zip.nextEntry
                    while (entry != null) {
                        val safeName = sanitizeEntryName(entry.name)
                        if (safeName == null) {
                            zip.closeEntry()
                            destDir.deleteRecursively()
                            return ImportResult.Failure(ImportResult.FailureReason.UNSAFE_PATH)
                        }

                        val outFile = File(destDir, safeName)
                        val outCanonical = outFile.canonicalFile

                        // Zip-slip guard: resolved path must remain inside destDir.
                        if (!outCanonical.path.startsWith(destCanonical.path + File.separator) &&
                            outCanonical.path != destCanonical.path
                        ) {
                            zip.closeEntry()
                            destDir.deleteRecursively()
                            return ImportResult.Failure(ImportResult.FailureReason.UNSAFE_PATH)
                        }

                        if (entry.isDirectory) {
                            outFile.mkdirs()
                        } else {
                            outFile.parentFile?.mkdirs()
                            BufferedOutputStream(FileOutputStream(outFile)).use { out ->
                                val buffer = ByteArray(8 * 1024)
                                var read = zip.read(buffer)
                                while (read >= 0) {
                                    totalWritten += read
                                    if (totalWritten > MAX_UNCOMPRESSED_BYTES) {
                                        zip.closeEntry()
                                        destDir.deleteRecursively()
                                        return ImportResult.Failure(ImportResult.FailureReason.IO_ERROR)
                                    }
                                    out.write(buffer, 0, read)
                                    read = zip.read(buffer)
                                }
                            }
                        }
                        zip.closeEntry()
                        entry = zip.nextEntry
                    }
                }
            } ?: run {
                destDir.deleteRecursively()
                return ImportResult.Failure(ImportResult.FailureReason.IO_ERROR)
            }
        } catch (e: Exception) {
            destDir.deleteRecursively()
            return ImportResult.Failure(ImportResult.FailureReason.IO_ERROR)
        }

        val entryHtml = FileUtils.findEntryHtml(destDir)
        if (entryHtml == null) {
            destDir.deleteRecursively()
            return ImportResult.Failure(ImportResult.FailureReason.NO_INDEX_HTML)
        }

        val project = CanvasProject(
            name = FileUtils.nameWithoutExtension(displayName).ifBlank { "Untitled Canvas" },
            folderName = folderName,
            entryRelativePath = entryHtml,
            sourceType = CanvasProject.SourceType.ZIP,
            sizeBytes = FileUtils.sizeOf(destDir)
        )
        repository.add(project)
        return ImportResult.Success(project)
    }

    /**
     * Normalizes a zip entry name and rejects anything that could escape the
     * destination directory: absolute paths, drive letters, "..", and any
     * entry whose normalized form starts with a path separator.
     */
    private fun sanitizeEntryName(rawName: String): String? {
        val name = rawName.replace('\\', '/')
        if (name.isBlank()) return null
        if (name.startsWith("/") || name.contains(":")) return null

        val segments = name.split("/")
        val cleanSegments = mutableListOf<String>()
        for (segment in segments) {
            when (segment) {
                "", "." -> { /* skip */ }
                ".." -> return null // reject any traversal attempt outright
                else -> cleanSegments.add(segment)
            }
        }
        if (cleanSegments.isEmpty()) return null
        return cleanSegments.joinToString(File.separator)
    }
}
