package com.canvaplayer.app

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.canvaplayer.app.databinding.ActivitySettingsBinding
import com.canvaplayer.app.util.ThemeManager

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnSettingsBack.setOnClickListener { finish() }

        when (ThemeManager.getSavedMode(this)) {
            ThemeManager.MODE_LIGHT -> binding.radioLight.isChecked = true
            ThemeManager.MODE_DARK -> binding.radioDark.isChecked = true
            else -> binding.radioSystem.isChecked = true
        }

        binding.radioLight.setOnClickListener { ThemeManager.setMode(this, ThemeManager.MODE_LIGHT) }
        binding.radioDark.setOnClickListener { ThemeManager.setMode(this, ThemeManager.MODE_DARK) }
        binding.radioSystem.setOnClickListener { ThemeManager.setMode(this, ThemeManager.MODE_SYSTEM) }
    }
}
