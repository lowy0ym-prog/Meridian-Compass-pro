package com.canvaplayer.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.widget.PopupMenu
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AlertDialog
import androidx.activity.result.contract.ActivityResultContracts
import com.canvaplayer.app.data.CanvasRepository
import com.canvaplayer.app.databinding.ActivityMainBinding
import com.canvaplayer.app.databinding.DialogRenameBinding
import com.canvaplayer.app.databinding.SheetAddCanvasBinding
import com.canvaplayer.app.databinding.SheetInfoBinding
import com.canvaplayer.app.databinding.SheetProjectMenuBinding
import com.canvaplayer.app.importer.HtmlImporter
import com.canvaplayer.app.importer.ImportResult
import com.canvaplayer.app.importer.ZipImporter
import com.canvaplayer.app.model.CanvasProject
import com.canvaplayer.app.model.LibraryFilter
import com.canvaplayer.app.model.SortMode
import com.canvaplayer.app.util.FileUtils
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.snackbar.Snackbar

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var repository: CanvasRepository
    private lateinit var adapter: CanvasLibraryAdapter

    private var currentFilter = LibraryFilter.ALL
    private var currentSort = SortMode.LAST_OPENED
    private var searchQuery = ""

    // Which kind of file we're expecting back from the system picker.
    private var pendingImportKind: ImportKind? = null
    private enum class ImportKind { HTML, ZIP }

    private val pickFileLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        val kind = pendingImportKind
        pendingImportKind = null
        if (uri != null && kind != null) {
            handlePickedFile(uri, kind)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        repository = CanvasRepository.getInstance(this)

        adapter = CanvasLibraryAdapter(
            onOpen = { project -> openCanvas(project) },
            onToggleFavorite = { project -> toggleFavorite(project) },
            onMoreOptions = { project -> showProjectMenu(project) }
        )
        binding.recyclerCanvases.layoutManager = LinearLayoutManager(this)
        binding.recyclerCanvases.adapter = adapter

        setupSearch()
        setupFilters()
        binding.btnSort.setOnClickListener { showSortMenu(it) }
        binding.btnSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        binding.fabAddCanvas.setOnClickListener { showAddCanvasSheet() }

        refreshList()
    }

    override fun onResume() {
        super.onResume()
        refreshList()
    }

    // ---------------------------------------------------------------------
    // Search & filters
    // ---------------------------------------------------------------------

    private fun setupSearch() {
        binding.editSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                searchQuery = s?.toString().orEmpty()
                refreshList()
            }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun setupFilters() {
        binding.filterChipGroup.setOnCheckedStateChangeListener { _, checkedIds ->
            currentFilter = when (checkedIds.firstOrNull()) {
                R.id.chipFavorites -> LibraryFilter.FAVORITES
                R.id.chipRecent -> LibraryFilter.RECENT
                else -> LibraryFilter.ALL
            }
            refreshList()
        }
    }

    private fun showSortMenu(anchor: View) {
        val popup = PopupMenu(this, anchor)
        popup.menu.add(0, 1, 0, getString(R.string.sort_name))
        popup.menu.add(0, 2, 1, getString(R.string.sort_date_added))
        popup.menu.add(0, 3, 2, getString(R.string.sort_last_opened))
        popup.setOnMenuItemClickListener { item ->
            currentSort = when (item.itemId) {
                1 -> SortMode.NAME
                2 -> SortMode.DATE_ADDED
                else -> SortMode.LAST_OPENED
            }
            refreshList()
            true
        }
        popup.show()
    }

    // ---------------------------------------------------------------------
    // List refresh (purely local — no network access anywhere in this method)
    // ---------------------------------------------------------------------

    private fun refreshList() {
        var list = repository.getAll()

        list = when (currentFilter) {
            LibraryFilter.ALL -> list
            LibraryFilter.FAVORITES -> list.filter { it.favorite }
            LibraryFilter.RECENT -> list.filter { it.lastOpened > 0L }
        }

        if (searchQuery.isNotBlank()) {
            list = list.filter { it.name.contains(searchQuery, ignoreCase = true) }
        }

        list = when (currentSort) {
            SortMode.NAME -> list.sortedBy { it.name.lowercase() }
            SortMode.DATE_ADDED -> list.sortedByDescending { it.dateAdded }
            SortMode.LAST_OPENED -> list.sortedByDescending { it.lastOpened }
        }

        adapter.submitList(list)

        val isEmptyLibrary = repository.getAll().isEmpty()
        binding.emptyState.visibility = if (isEmptyLibrary) View.VISIBLE else View.GONE
        binding.recyclerCanvases.visibility = if (isEmptyLibrary) View.GONE else View.VISIBLE
    }

    // ---------------------------------------------------------------------
    // Opening / favoriting
    // ---------------------------------------------------------------------

    private fun openCanvas(project: CanvasProject) {
        val updated = project.copy(lastOpened = System.currentTimeMillis())
        repository.update(updated)
        val intent = Intent(this, CanvasViewerActivity::class.java)
        intent.putExtra(CanvasViewerActivity.EXTRA_CANVAS_ID, updated.id)
        startActivity(intent)
    }

    private fun toggleFavorite(project: CanvasProject) {
        val updated = project.copy(favorite = !project.favorite)
        repository.update(updated)
        refreshList()
    }

    // ---------------------------------------------------------------------
    // Add Canvas
    // ---------------------------------------------------------------------

    private fun showAddCanvasSheet() {
        val dialog = BottomSheetDialog(this, R.style.Theme_CanvaPlayer_BottomSheet)
        val sheetBinding = SheetAddCanvasBinding.inflate(LayoutInflater.from(this))
        dialog.setContentView(sheetBinding.root)

        sheetBinding.optionImportHtml.setOnClickListener {
            dialog.dismiss()
            pendingImportKind = ImportKind.HTML
            pickFileLauncher.launch(arrayOf("text/html", "*/*"))
        }
        sheetBinding.optionImportZip.setOnClickListener {
            dialog.dismiss()
            pendingImportKind = ImportKind.ZIP
            pickFileLauncher.launch(arrayOf("application/zip", "application/x-zip-compressed", "*/*"))
        }
        dialog.show()
    }

    private fun handlePickedFile(uri: Uri, kind: ImportKind) {
        val displayName = FileUtils.queryDisplayName(this, uri) ?: "Untitled"
        val extension = FileUtils.extensionOf(displayName)

        val isHtml = extension == "html" || extension == "htm"
        val isZip = extension == "zip"

        if (kind == ImportKind.HTML && !isHtml) {
            Toast.makeText(this, R.string.import_failed_unsupported, Toast.LENGTH_LONG).show()
            return
        }
        if (kind == ImportKind.ZIP && !isZip) {
            Toast.makeText(this, R.string.import_failed_unsupported, Toast.LENGTH_LONG).show()
            return
        }

        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (e: SecurityException) {
            // Some providers don't support persistable permissions; the one-shot
            // read we're about to do will still work fine.
        }

        Toast.makeText(this, R.string.importing, Toast.LENGTH_SHORT).show()

        val result = if (kind == ImportKind.HTML) {
            HtmlImporter.importHtml(this, uri, displayName)
        } else {
            ZipImporter.importZip(this, uri, displayName)
        }

        when (result) {
            is ImportResult.Success -> {
                refreshList()
                Snackbar.make(binding.root, R.string.import_success, Snackbar.LENGTH_SHORT).show()
            }
            is ImportResult.Failure -> {
                val message = when (result.reason) {
                    ImportResult.FailureReason.NO_INDEX_HTML -> R.string.import_failed_no_index
                    ImportResult.FailureReason.UNSAFE_PATH -> R.string.import_failed_unsafe
                    ImportResult.FailureReason.UNSUPPORTED_FILE -> R.string.import_failed_unsupported
                    ImportResult.FailureReason.IO_ERROR -> R.string.import_failed
                }
                Snackbar.make(binding.root, message, Snackbar.LENGTH_LONG).show()
            }
        }
    }

    // ---------------------------------------------------------------------
    // Per-project menu (open / favorite / rename / delete / info)
    // ---------------------------------------------------------------------

    private fun showProjectMenu(project: CanvasProject) {
        val dialog = BottomSheetDialog(this, R.style.Theme_CanvaPlayer_BottomSheet)
        val sheetBinding = SheetProjectMenuBinding.inflate(LayoutInflater.from(this))
        dialog.setContentView(sheetBinding.root)

        sheetBinding.txtSheetTitle.text = project.name
        sheetBinding.txtMenuFavorite.setText(
            if (project.favorite) R.string.menu_unfavorite else R.string.menu_favorite
        )
        sheetBinding.imgMenuFavoriteIcon.setImageResource(
            if (project.favorite) R.drawable.ic_favorite_filled else R.drawable.ic_favorite_border
        )

        sheetBinding.menuOpen.setOnClickListener {
            dialog.dismiss()
            openCanvas(project)
        }
        sheetBinding.menuFavorite.setOnClickListener {
            dialog.dismiss()
            toggleFavorite(project)
        }
        sheetBinding.menuRename.setOnClickListener {
            dialog.dismiss()
            showRenameDialog(project)
        }
        sheetBinding.menuInfo.setOnClickListener {
            dialog.dismiss()
            showInfoSheet(project)
        }
        sheetBinding.menuDelete.setOnClickListener {
            dialog.dismiss()
            confirmDelete(project)
        }
        dialog.show()
    }

    private fun showRenameDialog(project: CanvasProject) {
        val dialogBinding = DialogRenameBinding.inflate(LayoutInflater.from(this))
        dialogBinding.editRenameName.setText(project.name)
        dialogBinding.editRenameName.setSelection(project.name.length)

        AlertDialog.Builder(this)
            .setTitle(R.string.rename_title)
            .setView(dialogBinding.root)
            .setNegativeButton(R.string.cancel, null)
            .setPositiveButton(R.string.save) { _, _ ->
                val newName = dialogBinding.editRenameName.text?.toString()?.trim().orEmpty()
                if (newName.isNotEmpty()) {
                    val updated = project.copy(name = newName)
                    repository.update(updated)
                    refreshList()
                }
            }
            .show()
    }

    private fun confirmDelete(project: CanvasProject) {
        AlertDialog.Builder(this)
            .setTitle(R.string.delete_title)
            .setMessage(getString(R.string.delete_message, project.name))
            .setNegativeButton(R.string.cancel, null)
            .setPositiveButton(R.string.delete) { _, _ ->
                repository.delete(project)
                refreshList()
            }
            .show()
    }

    private fun showInfoSheet(project: CanvasProject) {
        val dialog = BottomSheetDialog(this, R.style.Theme_CanvaPlayer_BottomSheet)
        val sheetBinding = SheetInfoBinding.inflate(LayoutInflater.from(this))
        dialog.setContentView(sheetBinding.root)

        sheetBinding.rowName.text = "${getString(R.string.info_name)}: ${project.name}"
        sheetBinding.rowDateAdded.text =
            "${getString(R.string.info_date_added)}: ${FileUtils.formatDate(project.dateAdded)}"
        sheetBinding.rowLastOpened.text =
            "${getString(R.string.info_last_opened)}: ${
                if (project.lastOpened > 0L) FileUtils.formatDate(project.lastOpened) else getString(R.string.never_opened)
            }"
        val liveSize = FileUtils.sizeOf(repository.projectDir(project))
        sheetBinding.rowSize.text = "${getString(R.string.info_size)}: ${FileUtils.humanReadableSize(liveSize)}"
        sheetBinding.rowInternet.text = "${getString(R.string.info_internet)}: ${getString(R.string.info_offline_always)}"

        sheetBinding.btnCloseInfo.setOnClickListener { dialog.dismiss() }
        dialog.show()
    }
}
