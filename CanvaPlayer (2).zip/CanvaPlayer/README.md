# Canva Player

A dedicated Android app for **running and interacting with** AI-generated
HTML/CSS/JS "Canvases" — buttons, menus, forms, drag-and-drop, animations,
`localStorage`, all of it — without ever turning into a general-purpose web
browser, and **structurally, permanently offline**.

This is not a browser. There is no address bar, no search engine, no way to
type an arbitrary URL, and no way to navigate to the open web from inside a
Canvas. The app requests no internet-related Android permission at all, so
no network connection can ever be opened by anything running inside it — a
Canvas's own JavaScript included. That's enforced by the operating system
itself, not just by app logic.

---

## Features

- **My Canvases** home library: rounded cards, search (local only — never
  touches the internet), Favorites/Recent filters, sort by name / date added
  / last opened. Search lives in a floating bottom pill bar (One UI 8.5's
  "search moved to the bottom" direction) instead of a top app-bar icon.
- **Import HTML** — pick a single `.html`/`.htm` file; it's copied into the
  app's private storage.
- **Import ZIP** — pick a `.zip` containing `index.html` + CSS/JS/images/
  fonts/assets; it's extracted preserving its folder structure, with
  zip-slip / path-traversal protection built in.
- **Open directly from a file manager** — tapping a `.html`/`.htm`/`.zip`
  file anywhere on the device and choosing "Canva Player" from the system
  "Open with…" sheet imports it into the library and opens it immediately,
  no need to go through "Add Canvas" first.
- **Canvas Viewer** — near full-screen WebView with a slim top bar
  (Back · Name · Reload · a permanent "Offline" badge). Full read/write
  interaction: taps, forms, `contenteditable` fields, drag-and-drop,
  animations, and `localStorage`/IndexedDB all work exactly as the Canvas
  was built.
- **Real Excel export — fully offline.** When a Canvas's own "Export"/
  "Download" button produces a CSV (the common case, exactly like the
  sample Event Call List's "Export for Excel" button), Canva Player
  automatically converts it into a genuine `.xlsx` workbook and hands you
  Android's normal "Save as" picker. No network request is ever made in
  this path — the bytes are pulled straight out of the page's own
  JavaScript. Non-CSV exports (images, JSON, etc.) are saved as-is. This
  works generically for any Canvas that triggers a download, not just one
  specific file.
- **Structurally offline — not just app logic.** The app has no
  `android.permission.INTERNET` at all, so the operating system itself
  refuses every network socket, for the whole app, permanently. See
  "The offline guarantee" below.
- **Offline-first storage** — everything after import lives on-device; no
  account, no cloud, no Google Play Services dependency.
- **Light / Dark / Follow system** appearance, persisted.
- **Built-in sample Canvases** — a small Test Canvas (tap button,
  `localStorage` counter, CSS animation, drag-and-drop) and the Event Call
  List sample, so you can instantly confirm the engine is really executing
  interactive HTML and try the Excel export flow immediately.
- **One UI 8.5–inspired UI** — floating, fully-rounded bottom sheets instead
  of hard-docked ones, a bottom-anchored search pill for one-handed reach,
  large rounded cards with real elevation, a gradient app icon and matching
  accent color — no proprietary Samsung assets used anywhere.

## Project structure

```
CanvaPlayer/
├── app/
│   ├── src/main/java/com/canvaplayer/app/
│   │   ├── MainActivity.kt            # "My Canvases" library screen
│   │   ├── CanvasViewerActivity.kt    # WebView player + export capture
│   │   ├── ImportEntryActivity.kt     # "Open with Canva Player" router
│   │   ├── SettingsActivity.kt        # Light/Dark/System picker
│   │   ├── CanvasLibraryAdapter.kt    # RecyclerView adapter for cards
│   │   ├── CanvaPlayerApp.kt          # Application class, seeds sample Canvases
│   │   ├── model/CanvasProject.kt     # Immutable data model
│   │   ├── data/CanvasRepository.kt   # Local JSON-backed persistence
│   │   ├── importer/HtmlImporter.kt   # Copies a single HTML file in
│   │   └── importer/ZipImporter.kt    # Secure ZIP extraction
│   │   └── util/                      # FileUtils, ThemeManager, XlsxWriter
│   ├── src/main/res/                  # Layouts, drawables, themes, strings
│   ├── src/main/assets/testcanvas/    # Bundled Test Canvas
│   ├── src/main/assets/eventcalllist/ # Bundled Event Call List sample
│   └── build.gradle.kts
├── .github/workflows/build-apk.yml    # CI build → debug APK artifact
├── build.gradle.kts
├── settings.gradle.kts
├── gradle.properties
├── gradle/wrapper/gradle-wrapper.properties
├── gradlew / gradlew.bat
└── local.properties.example
```

## Building

### Easiest: Android Studio
1. Open the `CanvaPlayer/` folder as a project in a recent Android Studio.
2. Let it sync Gradle (it will auto-generate `gradle-wrapper.jar`).
3. Run on a device/emulator, or **Build ▸ Build Bundle(s) / APK(s) ▸ Build APK(s)**.

### Command line
```bash
cd CanvaPlayer
cp local.properties.example local.properties   # then set sdk.dir
./gradlew assembleDebug
```
The APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

### About the Gradle wrapper
This archive includes `gradlew` / `gradlew.bat` and
`gradle/wrapper/gradle-wrapper.properties`, but **not** the small binary
`gradle-wrapper.jar` — it was produced in a sandboxed, network-disabled
environment that couldn't download it. Before using `./gradlew` directly,
either open the project once in Android Studio (it regenerates the jar
automatically), or run `gradle wrapper` with any locally installed Gradle 8.x.

The included **GitHub Actions workflow does not need this jar at all** — it
installs Gradle 8.7 itself and builds with that directly.

### GitHub Actions
`.github/workflows/build-apk.yml` runs on every push/PR to `main`/`master`
and can also be triggered manually. It checks out the repo (or unzips an
uploaded project archive), sets up JDK 17, accepts the pre-installed Android
SDK's licenses and installs the exact platform/build-tools needed, builds
`assembleDebug`, and uploads the resulting APK as a workflow artifact named
`canva-player-debug-apk`.

## The offline guarantee

This is the app's central design commitment, and it's enforced at more than
one level on purpose — never resting on a single check that could have a bug:

1. **No `INTERNET` permission, at all, anywhere in the manifest.** This is
   the strongest layer: it's an OS-level guarantee, not app logic. Android
   refuses every socket a process without this permission tries to open.
   A Canvas's JavaScript, a bug in this app's own Kotlin code, anything —
   none of it can open a network connection, because the process itself was
   never granted the ability to. You can verify this yourself by inspecting
   the APK's manifest; there is nothing to trust about app behavior here,
   only about a permission that either is or isn't declared.
2. **`shouldInterceptRequest` also blocks every `http://`/`https://` request
   unconditionally**, as a second, redundant layer — belt-and-suspenders on
   top of guarantee #1, in case this app is ever repurposed later and a
   permission is mistakenly re-added.
3. **Cross-origin `<iframe>`/`<embed>`/`<object>` elements are neutralized**
   at the DOM level via a document-start script, as a third layer — closing
   off the specific technique of embedding a live external page inside a
   Canvas (which would otherwise be a way a sufficiently determined Canvas
   author could try to build "browser-like" behavior). This can never
   actually trigger given guarantee #1, but it's there anyway.
4. **Top-level navigation is always blocked** in `shouldOverrideUrlLoading`
   — a tapped link, `window.location = "..."`, a form submit, anything. This
   is independent of network access entirely: it's what stops a Canvas from
   ever taking over the screen with something other than its own local page.
5. **No new windows/tabs, ever** — `window.open()`/`target="_blank"` are
   disabled at the settings level and refused again at `onCreateWindow`.
6. **There is no address bar, URL field, or search box anywhere in the
   app** — no UI surface exists for arbitrary browsing even in principle.

### What this means if you (or any AI) build a Canvas that tries to "search
### like a browser" or fetch images from the web

It will not work, and not just because of app-side blocking that could in
principle have a bug — such a Canvas's `fetch()`/`XMLHttpRequest` calls, or
an `<img src="https://...">` pointing at a remote server, will fail outright
because the app has no ability to open a network connection at all. This
holds regardless of how the Canvas is written, by you, by another AI, or by
anyone else. A Canvas can only ever use its own bundled local files
(HTML/CSS/JS/images that were part of the imported project) — nothing it
tries to fetch from the internet will ever load.

### What still works fully offline

Exporting to Excel (or any file) from a Canvas's own export button works
exactly as before — that flow never needed the network in the first place;
it reads the file straight out of the page's own JavaScript (a `blob:` or
`data:` URL) and writes it to a location you pick on your device.

## How the WebView is locked down

- Local project files are served through `androidx.webkit.WebViewAssetLoader`
  at `https://appassets.androidplatform.net/canvas/…` rather than raw
  `file://` URLs — the security-recommended way to let a WebView load local
  HTML/CSS/JS/images while keeping `allowFileAccess` disabled.
- ZIP extraction rejects absolute paths, drive letters, and `..` segments,
  and double-checks every entry's resolved canonical path is still inside the
  destination project folder before writing anything to disk.
- The only JavaScript bridge exposed to a Canvas (`AndroidExport`) has
  exactly two methods, both write-only from the page's point of view: hand
  Android some file bytes to save, or report that a blob read failed.
- `ImportEntryActivity` (the file-manager entry point) only ever accepts a
  single local file Uri the system hands it, imports that one file exactly
  like the in-app "Add Canvas" flow, and opens the sandboxed viewer.

## How Excel export works

1. A Canvas's export button creates a `blob:` (or `data:`) URL and clicks a
   hidden `<a download>` link — the standard technique. Canva Player catches
   that via `WebView.setDownloadListener`.
2. For a `blob:` URL, an injected script re-fetches the blob from inside the
   page and hands the bytes back to Android as base64.
3. A document-start script delays `URL.revokeObjectURL()` by a few seconds
   so a Canvas that revokes the blob immediately after triggering the
   download (as many do) can't race ahead of step 2.
4. If the resulting file looks like CSV, it's parsed and rewritten as a
   genuine `.xlsx` workbook (`util/XlsxWriter.kt` — a small, dependency-free
   OOXML writer, no Apache POI needed) before the save dialog appears.
5. Android's standard "Save as" (Storage Access Framework) dialog opens so
   you pick where the file goes — no storage permission required, and no
   network involved anywhere in this path.

## Notes / things to double-check

- This project was built file-by-file in a sandbox without Android SDK/
  Gradle available to actually compile it. Validation so far has caught and
  fixed: a wrong XML namespace URI (`res/app` instead of `res-auto`, which
  broke every `app:` attribute), a style missing a `parent` attribute
  (implicit-parent resolution failure), a malformed WebView origin-rule
  string (crashed every Canvas open), and a mutable-shared-object bug that
  silently broke the favorites toggle (fixed by making `CanvasProject`
  immutable — see below). All were found by working through real build/
  runtime failures, not guessed at in advance; a first real Gradle build and
  device test remain the authoritative check for anything not yet exercised.
- `CanvasProject` is now a fully immutable data class (every field `val`).
  Any change goes through `.copy(...)` to produce a new instance — this is
  what makes `RecyclerView`'s `DiffUtil` correctly detect changes like
  favoriting; mutating a shared instance in place made old/new comparisons
  trivially equal, so the UI never redrew.
- The blob-download capture relies on `WebViewFeature.DOCUMENT_START_SCRIPT`
  and modern WebView support for `DownloadListener` firing on `blob:` URLs.
  Both are present on current, Play Store–updated System WebView. Canva
  Player checks `WebViewFeature.isFeatureSupported(...)` first and wraps
  both document-start scripts in `try/catch`, degrading gracefully rather
  than crashing if either isn't available.
- Minimum SDK 24 (Android 7.0), target/compile SDK 34, Kotlin 1.9.24, AGP
  8.5.2.
- The app icon is an original design (a gradient rounded "canvas frame" with
  a play triangle) and uses no Canva or Samsung trademarks or assets. The
  One UI 8.5 direction (floating fully-rounded sheets, bottom-anchored
  search) is based on Samsung's own May 2026 rollout coverage, not any
  bundled Samsung code or graphics.
